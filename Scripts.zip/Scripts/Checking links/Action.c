//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("2", "Navigate to 'https://qainterview.pythonanywhere.com/'", "snapshot=Action_2.inf");
	/* Checking about link */
	truclient_step("4", "Click on About link", "snapshot=Action_4.inf");
	truclient_step("5", "Go Back a page", "snapshot=Action_5.inf");
	/* Checking terms and conditions link */
	truclient_step("7", "Click on Terms and Conditions link", "snapshot=Action_7.inf");
	truclient_step("8", "Go Back a page", "snapshot=Action_8.inf");
	/* checking privacy link */
	truclient_step("10", "Click on Privacy link", "snapshot=Action_10.inf");
	truclient_step("11", "Go Back a page", "snapshot=Action_11.inf");
	/* checking services link */
	truclient_step("13", "Click on Qxf2 Services link", "snapshot=Action_13.inf");
	truclient_step("14", "Go Back a page", "snapshot=Action_14.inf");
	truclient_step("15", "Exit Action with status Pass", "snapshot=Action_15.inf");

	return 0;
}
