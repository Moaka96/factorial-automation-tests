//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'https://qainterview.pythonanywhere.com/'", "snapshot=Action_1.inf");
	truclient_step("2", "Click on Enter an integer textbox", "snapshot=Action_2.inf");
	truclient_step("3", "Type -1 in Enter an integer textbox", "snapshot=Action_3.inf");
	truclient_step("4", "Click on Calculate! button", "snapshot=Action_4.inf");
	/* Factorial is not defined for negative numbers. Script exits with a Fail state */
	truclient_step("6", "Exit Action with status Fail", "snapshot=Action_6.inf");

	return 0;
}
