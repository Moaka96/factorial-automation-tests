//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Evaluate JavaScript code // Start E2E Transaction...ctionName);  }", "snapshot=Action_1.inf");
	truclient_step("2", "Navigate to 'https://qainterview.pythonanywhere.com/'", "snapshot=Action_2.inf");
	truclient_step("3", "Click on Enter an integer textbox", "snapshot=Action_3.inf");
	truclient_step("4", "Type randomNum in Enter an integer textbox", "snapshot=Action_4.inf");
	truclient_step("5", "Click on Calculate! button", "snapshot=Action_5.inf");
	truclient_step("6", "If The factorial step exist exists", "snapshot=Action_6.inf");
	{
		truclient_step("6.1", "Evaluate JavaScript code // Start E2E Transaction...ctionName);  }", "snapshot=Action_6.1.inf");
	}
	truclient_step("Else");
	{
		truclient_step("6.1", "Exit Action with status Fail", "snapshot=Action_6.1.inf");
	}

	return 0;
}
