//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	truclient_step("1", "Navigate to 'http://qainterview.pythonanywhere.com/'", "snapshot=Action_1.inf");
	truclient_step("2", "Click on Enter an integer textbox", "snapshot=Action_2.inf");
	truclient_step("3", "Type 12 in Enter an integer textbox", "snapshot=Action_3.inf");
	truclient_step("4", "Click on Calculate! button", "snapshot=Action_4.inf");
	truclient_step("5", "If The factorial of 12 is:... exists", "snapshot=Action_5.inf");
	{
		truclient_step("5.1", "Exit Action with status Pass", "snapshot=Action_5.1.inf");
	}
	truclient_step("Else");
	{
		truclient_step("5.1", "Exit Action with status Fail", "snapshot=Action_5.1.inf");
	}

	return 0;
}
